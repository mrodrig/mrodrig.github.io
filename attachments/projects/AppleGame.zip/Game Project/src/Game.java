import funworld.*;
import colors.*;
import tester.*;
import geometry.*;

import java.awt.Color;

// Assignment 5 Problem 1
// Michael Rodrigues
// mrodrig
// Michael Ravert
// ravert1
// 14 February 2012

/* CLASS DIAGRAM:
                           +----------------+
                           |      Game      |
                           +----------------+
                                    ^
                                    |
              +---------------------+----------------------------------+
              |                                                        |
    +---------+---------+                                +---------------------+
    |      IApple       |                                |        Basket       |
    +-------------------+                                +---------------------+
            / \                                          | int               x |
           /   \                                         | int     caughtApples|
           -----                                         | int numberGoodApples|
             |                                           +---------------------+
       +-----+--------------------+
       |                          |
+------+------+           +----------------+
| EmptyApples |           |   ConsApples   |
+-------------+           +----------------+
                +---------| Apple    first |
                |         | IApple    rest |             +------------------+
           +----+         +----------------+    +------->|      CartPt      |
           |                                    |        +------------------+
 +---------+---------+                    +-----+        |  int          x  |
 |       Apple       |                    |              |  int          y  |
 +-------------------+                    |              +------------------+
 | CartPt  loc       |--------------------+
 | boolean goodApple |
 +-------------------+

*/

/*
 * You are going apple picking with a friend that can sometimes be a bit
 * obnoxious.  Today while picking apples with you, he decides to see how many
 * good apples you can catch in the basket while avoiding the bad apples.  Each
 * good apple counts for one point towards your total score, while bad apples
 * do not help your score.  Your basket only holds 25 apples, so choose which
 * apples you catch wisely.  Use your left and right arrow keys to move your
 * basket in order to catch the apples falling from the top of the screen.
 * 
 * The maximum score is 25 which is obtainable but you have to be very picky.
 * Good luck and have fun!
 */

// to represent a posn with methods necessary for the game
class CartPt extends Posn{
    CartPt(int x, int y){
        super(x, y);
    }
    
    /*
     * FIELDS:
     * ... this.x ...                            -- int
     * ... this.y ...                            -- int
     * 
     * METHODS:
     * ... this.moveDown() ...                   -- CartPt
     * ... this.isNear(int) ...                  -- boolean
     * ... this.newRandom() ...                  -- CartPt
     * ... this.offCanvas() ...                  -- boolean
     * 
     * METHODS FOR FIELDS:
     * 
     */
    
    // move this CartPt down by 20 pixels
    public CartPt moveDown(){
        return new CartPt(this.x, this.y + 20);
    }
    
    // determine whether this location is near the given x value
    public boolean isNear(int x){
        return (Math.sqrt(Math.pow(Math.abs(this.x - x), 2)
                       + Math.pow(Math.abs(this.y - 473), 2)) <= 50);
        // 473 = the y value of the basket (never changes)
    }
    
    // return a new random location based on this location
    public CartPt newRandom(){
    	return new CartPt((int) (300 + ((Math.random() * 1000) % 153)), 200);
    	// multiply the random number between 0.00 and 1.00 by 100 and modulo it
    	//   by 153 to keep the game interesting - moves an apples x value
    }
    
    // is this apple off the canvas?
    public boolean offCanvas(){
    	if (this.y >= 546) // 546 = bottom of canvas
    		return true;
    	else return false;
    }
}

// to represent an apple that drops from the tree
class Apple {
    CartPt loc;
    boolean goodApple;
        
    Apple(CartPt loc, boolean goodApple){
        this.loc = loc;
        this.goodApple = goodApple;
    }
    
    /*
     * FIELDS:
     * ... this.loc ...                          -- CartPt
     * ... this.goodApple ...                    -- boolean
     * 
     * METHODS:
     * ... this.makeAppleImage() ...             -- WorldImage
     * ... this.moveApple() ...                  -- Apple
     * ... this.nearBasketHuh(Basket) ...        -- boolean
     * ... this.replaceApple() ...               -- Apple
     * 
     * METHODS FOR FIELDS:
     * ... this.loc.moveDown() ...               -- CartPt
     * ... this.loc.isNear(int) ...              -- boolean
     * ... this.loc.newRandom() ...              -- CartPt
     * ... this.loc.offCanvas() ...              -- boolean
     */
    
    // produce an image of this apple at the apple's location
    public WorldImage makeAppleImage(){
        if (this.goodApple == true)
                    return new FromFileImage(this.loc, "good-apple.png");
        // the image of a good apple
                else return new FromFileImage(this.loc, "rotten-apple.png");
        // the image of a bad apple - avoid these in the game.
    }
    
    // move this apple down by 20 pixels
    public Apple moveApple(){
        return new Apple(this.loc.moveDown(), this.goodApple);
    }
    
    // is this apple close to the given basket?
    public boolean nearBasketHuh(Basket that){
        return this.loc.isNear(that.x);
    }
    
    // replace this apple that was not caught by a basket
    public Apple replaceApple(){
        return new Apple(this.loc.newRandom(), this.goodApple);
    }
}

class Basket {
    int x;
    int caughtApples;
    int numberGoodApples;
    WorldImage basketImage;
    
    Basket(int x, int caughtApples, int numberGoodApples){
        this.x = x;
        this.caughtApples = caughtApples;
        this.numberGoodApples = numberGoodApples;
        this.basketImage = new FromFileImage(new CartPt(this.x, 473), "basket.png");
    }
    
    // secondary constructor which resembles an original game state:
    //    no apples have been caught yet
    Basket(int x, int caughtApples){
    	this(x, caughtApples, 0);
    }
    
    /*
     * FIELDS:
     * ... this.x ...                            -- int
     * ... this.caughtApples ...                 -- int
     * ... this.numberGoodApples ...             -- int
     * ... this.basketImage ...                  -- WorldImage
     * 
     * METHODS:
     * ... this.moveBasket(int) ...              -- Basket
     * ... this.onKey(String) ...                -- Basket
     * ... this.addNewApple(IApple) ...          -- Basket
     * ... this.basketFullHuh() ...              -- boolean
     * ... this.onTick(IApple) ...               -- Basket
     * 
     * METHODS FOR FIELDS:
     * 
     */
    
    // move this basket in the given direction
    public Basket moveBasket(int dir){
        if (dir == 1)
            return new Basket(this.x + 10, this.caughtApples, 
            		                                     this.numberGoodApples);
        // move basket 10 pixels to the right
        else return new Basket(this.x - 10, this.caughtApples,
        		                                         this.numberGoodApples);
        // move basket 10 pixels to the left
    }
    
    // adjust this basket based on the given keyEvent
    public Basket onKey(String ke){
        if (ke.equals("left"))
            return this.moveBasket(-1); // -1 = move to left
        else {if (ke.equals("right"))
        	return this.moveBasket(1);  // 1  = move to right
        else return this;}              // otherwise return same basket
    }
    
    // add any of the given apples that are in range to this basket
    //   and add all god apples that are in range to the running tally
    public Basket addNewApples(IApple loa){
        return new Basket(this.x, this.caughtApples + loa.allInRange(this), 
        		// add all apples caught to running tally
        		          this.numberGoodApples + loa.allGoodInRange(this));
        // add good apples to the running tally
    }
    
    // is this basket full?
    public boolean basketFullHuh(){
    	return this.caughtApples >= 25; // 25 or more = this basket is full 
    }
    
    // update this basket on every "tick" of the game
    public Basket onTick(IApple apples){
    	if (apples.anyInRange(this)) // check to see if any apples are in range
    		return addNewApples(apples); // update the basket's caught numbers
    	else return this;
    }
}

interface IApple{
	// move all apples in this list
    public IApple moveAllApples();
    
    // produce the image of all apples in this list
    public WorldImage makeApplesImage();
    
    // update the apples in this list based on the position of the given basket
    public IApple onTick(Basket b);
    
    // are any of the apples in this list in range of the given basket?
    public boolean anyInRange(Basket b);
    
    // how many of the apples in this list are in range of the given basket?
    public int allInRange(Basket b);
    
    // how many of the apples in this list are good and in range of the
    //    given basket?
    public int allGoodInRange(Basket b);
}

// to represent an empty list of apples
class EmptyApples implements IApple{
    EmptyApples(){}
    
    /*
     * FIELDS:
     * 
     * METHODS:
     * ... this.moveAllApples ...                -- IApple
     * ... this.makeApplesImage() ...            -- WorldImage
     * ... this.replaceApples() ...              -- IApple
     * ... this.onTick(Basket) ...               -- IApple
     * ... this.anyInRange(Basket) ...           -- boolean
     * ... this.allInRange(Basket) ...           -- int
     * ... this.allGoodInRange(Basket) ...       -- int
     * 
     * METHODS FOR FIELDS:
     * 
     */
    
    // move all apples in this empty list of apples
    public IApple moveAllApples(){
        return this;
    }
    
    // produce an image of all apples in this empty list
    public WorldImage makeApplesImage(){
    	return new RectangleImage(new Posn(0, 0), 0, 0, new White());
    }
    
    // update this empty list when the game "ticks"
    public IApple onTick(Basket b){
    	return this;
    }
    
    // are any apples in this empty list in range of the given basket?
    public boolean anyInRange(Basket b){
    	return false;
    }
    
    // how many apples in this empty list are in range of the given basket?
    public int allInRange(Basket b){
    	return 0;
    }
    
    // how many apples in this empty list are good and in range of the
    //    given basket?
    public int allGoodInRange(Basket b){
    	return 0;
    }
}

// to represent a list of apple(s)
class ConsApples implements IApple{
    Apple first;
    IApple rest;
    
    ConsApples(Apple first, IApple rest){
        this.first = first;
        this.rest = rest;
    }
    
    /*
     * FIELDS:
     * ... this.first ...                        -- Apple
     * ... this.rest ...                         -- IApple
     * 
     * METHODS:
     * ... this.moveAllApples ...                -- IApple
     * ... this.makeApplesImage() ...            -- WorldImage
     * ... this.onTick(Basket) ...               -- IApple
     * ... this.anyInRange(Basket) ...           -- boolean
     * ... this.allInRange(Basket) ...           -- int
     * ... this.allGoodInRange(Basket) ...       -- int
     * 
     * METHODS FOR FIELDS:
     * ... this.first.makeAppleImage() ...       -- WorldImage
     * ... this.first.moveApple() ...            -- Apple
     * ... this.first.nearBasketHuh(Basket) ...  -- boolean
     * ... this.first.replaceApple() ...         -- Apple
     * 
     * ... this.rest.moveAllApples ...           -- IApple
     * ... this.rest.makeApplesImage() ...       -- WorldImage
     * ... this.rest.onTick(Basket) ...          -- IApple
     * ... this.rest.anyInRange(Basket) ...      -- boolean
     * ... this.rest.allInRange(Basket) ...      -- int
     * ... this.rest.allGoodInRange(Basket) ...  -- int
     */
    
    // move all apples in this list
    public IApple moveAllApples(){
        return new ConsApples(this.first.moveApple(), // move the first apple
                              this.rest.moveAllApples()); // move the rest
    }
    
    // make the image of the apples in this list
    public WorldImage makeApplesImage(){
        return this.first.makeAppleImage().overlayImages( // overlay this onto
        		this.rest.makeApplesImage());             // the rest 
    }
    
    // update this list of apples when the game "ticks"
    public IApple onTick(Basket b){
    	if (this.first.loc.offCanvas() || this.first.nearBasketHuh(b))
    		// off screen              OR       was caught
    		return new ConsApples(this.first.replaceApple(), // replace apple
    				              this.rest.onTick(b));      // check the rest
    	else return new ConsApples(this.first.moveApple(),
    			                   this.rest.onTick(b));
    }
    
    // are any apples in this list in range of the given basket?
    public boolean anyInRange(Basket b){
    	return this.first.nearBasketHuh(b) || this.rest.anyInRange(b);
    }
    
    // how many of the apples in this list are in range of the given basket?
    public int allInRange(Basket b){
    	if (this.first.nearBasketHuh(b))        // if first is in range,
    		return 1 + this.rest.allInRange(b); // add one and check rest
    	else return this.rest.allInRange(b);    // else, check rest
    }
    
    // how many of the apples in this list are good and in range of the
    //    given basket?
    public int allGoodInRange(Basket b){
    	if (this.first.nearBasketHuh(b) &&          // if first is near basket
    	    this.first.goodApple == true)           // and is a good apple
    		return 1 + this.rest.allGoodInRange(b); // add one and check rest
    	else return this.rest.allGoodInRange(b);    // else, check the rest 
    }
}

// to represent the world of the game
class Game extends World{
    int WIDTH = 700;      // constant values, never change
    int HEIGHT = 546;     // constant values, never change
    Basket basket;        // the basket in the game
    IApple apples;        // the apples in the game
    
    Game(Basket basket, IApple apples){
        this.basket = basket;
        this.apples = apples;
    }
    
    /*
     * FIELDS:
     * ... this.basket ...                       -- Basket
     * ... this.apples ...                       -- IApple
     * 
     * METHODS:
     * ... this.makeImage() ...                  -- WorldImage
     * ... this.onKeyEvent(String) ...           -- Game
     * ... this.onTick() ...                     -- Game
     * ... this.worldEnds() ...                  -- WorldEnd
     * 
     * METHODS FOR FIELDS:
     * ... this.basket.moveBasket(int) ...       -- Basket
     * ... this.basket.onKey(String) ...         -- Basket
     * ... this.basket.addNewApple(IApple) ...   -- Basket
     * ... this.basket.basketFullHuh() ...       -- boolean
     * ... this.basket.onTick(IApple) ...        -- Basket
     * 
     * ... this.apples.moveAllApples ...         -- IApple
     * ... this.apples.makeApplesImage() ...     -- WorldImage
     * ... this.apples.onTick(Basket) ...        -- IApple
     * ... this.apples.anyInRange(Basket) ...    -- boolean
     * ... this.apples.allInRange(Basket) ...    -- int
     * ... this.apples.allGoodInRange(Basket) ...-- int
     */
    
    // produce the image of this world with the basket and apples
    public WorldImage makeImage(){
        return
    new FromFileImage(new CartPt(350, 273), "new-background.png"). // background
        overlayImages(this.apples.makeApplesImage(), // images of the apples
                      this.basket.basketImage);      // image of the basket
    }
    
    // update this world for the given key event
    public Game onKeyEvent(String ke){
  	  return new Game(this.basket.onKey(ke), this.apples); // update on key evnt
    }
    
    // update this world with every on every "tick"
    public Game onTick(){
  	  return new Game(this.basket.onTick(this.apples), // update basket and
  			           this.apples.onTick(this.basket)); // apples on tick
  	 }
    
    // end the world when the game is over
    public WorldEnd worldEnds(){
        if (this.basket.basketFullHuh())
          return new WorldEnd(true, // end the world
        this.makeImage().overlayImages( // and print the users score
            new TextImage(new Posn(350, 273), "Game Over! Your score: " + 
                                                   this.basket.numberGoodApples, 
                15, 3, new Red())));
        else 
          return new WorldEnd(false, this.makeImage());
      }
}

// to represent examples and tests for the game
class ExamplesGame {
    CartPt posn1 = new CartPt(356, 470);
    CartPt posn2 = new CartPt(356, 490);
    CartPt posn3 = new CartPt(356, 510);
    CartPt posn4 = new CartPt(701, 350);
    CartPt posn5 = new CartPt(30, 30);
    CartPt posn6 = new CartPt(350, 550);
    Basket b1 = new Basket(350, 0);
    Basket b2 = new Basket(360, 0);
    Basket b3 = new Basket(340, 0);
    Basket b4 = new Basket(350, 1, 1);
    Basket b5 = new Basket(170, 0);
    Basket b6 = new Basket(350, 25, 13);
    Apple a1 = new Apple(this.posn1, true);
    Apple a2 = new Apple(this.posn5, false);
    Apple a3 = new Apple(this.posn2, true);
    Apple a4 = new Apple(new CartPt(30, 50), false);
    Apple a5 = new Apple(new CartPt(351, 470), false);
    IApple loa1 = new ConsApples(this.a1, new ConsApples(this.a2, new EmptyApples()));
    IApple loa2 = new ConsApples(this.a3, new ConsApples(this.a4,
    		                                                new EmptyApples()));
    IApple loa3 = new ConsApples(this.a3, new ConsApples(this.a5,
    														new EmptyApples()));
    IApple loa4 = new ConsApples(this.a2, new EmptyApples());
    IApple loa5 = new ConsApples(this.a4, new EmptyApples());
    IApple loa6 = new ConsApples(this.a1.replaceApple(),
    		      new ConsApples(this.a2.replaceApple(),
    		      new ConsApples(this.a3.replaceApple(),
    		    		  new EmptyApples())));
    
    Game ow = new Game(this.b1, this.loa1);
    Game owtest1 = new Game(this.b2, this.loa1);
    Game owtest2 = new Game(this.b3, this.loa1);
    Game owtest3 = new Game(this.b1, this.loa2);
    Game owtest4 = new Game(this.b6, this.loa1);
    Game owtest5 = new Game(this.b1, this.loa4);
    Game owtest6 = new Game(this.b1, this.loa5);
    Game gameworld = new Game(this.b1, this.loa6);
        
    // run this world at the tick rate 0.1
    public boolean testRunWorld(Tester t){
      return this.gameworld.bigBang(700, 546, 0.1);
     }
    
    // test the MoveDown method in CartPt
    public boolean testMoveDown(Tester t){
    	return
    t.checkExpect(this.posn1.moveDown(), this.posn2) &&
    t.checkExpect(this.posn2.moveDown(), this.posn3);
    }
    
    // test the isNear method in CartPt
    public boolean testIsNear(Tester t){
    	return
    t.checkExpect(this.posn1.isNear(0), false) &&
    t.checkExpect(this.posn1.isNear(356), true) &&
    t.checkExpect(this.posn2.isNear(356), true) &&
    t.checkExpect(this.posn2.isNear(300), false);
    }
    
    // test the offCanvas method in CartPt
    public boolean testOffCanvas(Tester t){
    	return
    t.checkExpect(this.posn1.offCanvas(), false) &&
    t.checkExpect(this.posn4.offCanvas(), false) &&
    t.checkExpect(this.posn6.offCanvas(), true);
    }
    
    // test the makeAppleImage method in Apple
    public boolean testMakeAppleImage(Tester t){
    	return
    t.checkExpect(this.a1.makeAppleImage(), 
    		new FromFileImage(this.posn1, "good-apple.png")) &&
    t.checkExpect(this.a2.makeAppleImage(), 
    		new FromFileImage(this.posn5, "rotten-apple.png"));	
    }
    
    // test the moveApple method in Apple
    public boolean testMoveApple(Tester t){
    	return
    t.checkExpect(this.a1.moveApple(), new Apple(this.posn2, true)) &&
    t.checkExpect(this.a2.moveApple(), new Apple(new CartPt(30, 50), false));
    }
    
    // test the nearBasketHuh method in Apple
    public boolean testNearBasketHuh(Tester t){
    	return
    t.checkExpect(this.a1.nearBasketHuh(this.b1), true) &&
    t.checkExpect(this.a1.nearBasketHuh(new Basket(250, 23)), false);
    }
    
    // test the moveBasket method in Basket
    public boolean testMoveBasket(Tester t){
    	return
    t.checkExpect(this.b1.moveBasket(1), this.b2) &&
    t.checkExpect(this.b1.moveBasket(-1), this.b3);
    }
    
    // test the onKey method in Basket
    public boolean testOnKey(Tester t){
    	return
    t.checkExpect(this.b1.onKey("right"), this.b2) &&
    t.checkExpect(this.b1.onKey("left"), this.b3);
    }
    
    // test the addNewApples method in Basket
    public boolean testAddNewApples(Tester t){
    	return
    t.checkExpect(this.b1.addNewApples(this.loa1), this.b4) &&
    t.checkExpect(this.b5.addNewApples(this.loa1), this.b5);
    }
    
    // test the basketFullHuh method in Basket
    public boolean testBasketFullHuh(Tester t){
    	return
    t.checkExpect(this.b1.basketFullHuh(), false) &&
    t.checkExpect(this.b6.basketFullHuh(), true);
    }
    
    // test the onTick method in Basket
    public boolean testonTickBasket(Tester t){
    	return
    t.checkExpect(this.b1.onTick(this.loa1), new Basket(350, 1, 1)) &&
    t.checkExpect(this.b5.onTick(this.loa1), new Basket(170, 0));
    }
    
    // test the moveAllApples method in Basket
    public boolean testMoveAllApples(Tester t){
    	return
    t.checkExpect(this.loa1.moveAllApples(), this.loa2);
    }
    
    // test the anyInRange method in Basket
    public boolean testAnyInRange(Tester t){
    	return
    t.checkExpect(this.loa1.anyInRange(this.b1), true) &&
    t.checkExpect(this.loa2.anyInRange(this.b5), false);
    }
    
    // test the allInRange method in Basket
    public boolean testAllInRange(Tester t){
    	return
    t.checkExpect(this.loa1.allInRange(this.b1), 1) &&
    t.checkExpect(this.loa2.allInRange(this.b5), 0);
    }
    
    // test the allGoodInRange method in Basket
    public boolean testAllGoodInRange(Tester t){
    	return
    t.checkExpect(this.loa1.allGoodInRange(this.b1), 1) &&
    t.checkExpect(this.loa1.allGoodInRange(this.b5), 0) &&
    t.checkExpect(this.loa3.allGoodInRange(this.b1), 1);
    }
    
    // test the onKey method in Game
    public boolean testMakeImage(Tester t){
    	return
    t.checkExpect(this.ow.onKeyEvent("right"), this.owtest1) &&
    t.checkExpect(this.ow.onKeyEvent("left"), this.owtest2);
    }
    
    // test the onTick method in Game
    public boolean testOnTickGame(Tester t){
    	return
    t.checkExpect(this.owtest5.onTick(), this.owtest6);
    // can't test the case where a new random apple is generated because of the
    //     element of randomness in the apple's location.
    // Based on actually running the game and testing it though, the method
    //     works as it was designed to.
    }
    
    // test the worldEnds method in Basket
    public boolean testWorldEnds(Tester t){
    	return
    t.checkExpect(this.ow.worldEnds(), 
    		new WorldEnd(false, this.ow.makeImage())) &&
    t.checkExpect(this.owtest4.worldEnds(),
    		new WorldEnd(true, 
    		        this.owtest4.makeImage().overlayImages( 
    		            new TextImage(new Posn(350, 273),
    		            		"Game Over! Your score: " + 
    		                    13, 
    		                15, 3, new Red()))));
    }
}